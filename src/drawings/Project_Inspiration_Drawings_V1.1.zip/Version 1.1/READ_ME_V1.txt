READ ME V1

---------------------------------
Disclaimer and Version management
---------------------------------
This machine should be certified and checked by the medical professionals of your country.

For any questions about the drawings, please send an email to drawings@projectinspiration.nl

This is V1 of the machine. On each drawing, the revision number should be 1.
Each drawing should have Checked and approved written on it, and the 'preliminary' blacked out.

For the latest version go to https://github.com/CombatCovid/TU-Delft-PI-Emergency-Ventilator
More information can be found on https://projectinspiration.nl


-----------------------
Standard drawing notes:
-----------------------
DEBURR AND BREAK SHARP EDGES

UNLESS OTHERWISE SPECIFIED:
DIMENSIONS ARE IN MILLIMETERS 
SURFACE FINISH: Ra 1.6 

TOLERANCES:
LINEAR: 0.1mm 
ANGULAR: 3 degrees


-------------------------------------
Stock sizes and roughness indications
-------------------------------------
All faces in contact with air or bearing surfaces have a maximum roughness of 0.8 micro meter Ra. Other faces have a standard roughness of 1.6, unless specified otherwise.
Parts have been designed so that stock material can be used in the following places:
	40x40mm AISI 316L Stock
	The bellow and valve assembly can be made from 40x40mm stock. As specified on the drawings, the outside roughness can be up to 3.2 Ra for these faces, and just have to be internally machined.
	
	Axle material
	All axle material is standard sizes (6,8, 10 and 12 mm). The fit and surface finish of standard smooth shaft should be good enough, but is is specified on each drawing.

	


----------------------------------------------------------
Materials used and possible replacements if not available:
----------------------------------------------------------

AISI 316L
Parts touching the air going to the patient are made from AISI 316L
	1. First replacement option:
	Another type of stainless steel, like AISI 304. This is less suited for high oxygen percentages.
	2. Second replacement option:
	Anodised aluminium 6082. Also less suited for high oxygen percentages

AISI 304
Parts that do not touch the air going to the patient are made from AISI 304
	1. First replacement option:
	Other type of stainless steel
	2. Second replacement option:
	Using coated steel parts to prevent corrosion

AISI 440C
The two valvecams are made of AISI 440C stainless steel. This has to be hardened to limit wear on the cams
	1. First replacement option:
	Another type of hardened stainless steel
	2. Second replacement option:
	Hardened coated steel 

PolyUrethane (PU)
Bellow and disks in valves are made from a food safe PU. PU is very durable, but not autoclavable.
These parts can be washed with alcohol.

Nylon
The plain or slide bearings are made from nylon. Also the 3D printed Followerguide (PI.04.01.02.03) is made from nylon
	1. First replacement option:
	Another type of wear resistant plastic suited for bushings could be used.

NEMA FR-2 
The bellowcam (PI.02.01.00.03) is made from NEMA FR-2 or pertinax. At the moment we are testing POM as a replacement.
	1. First replacement option:
	Another type of wear resistant and hard plastic could be used.

Viton
The gaskets are made from Viton.
	1. First replacement option:
	Silicone or other latex free rubber.

Silicone
The umbrella valve in the check valve is made from silicone. 
It can be ordered from the following company https://www.better-silicone.com
The valve fits in the valveplate (PI.03.01.04.17) which can be easily altered to fit another type of umbrella valve.

PolyCarbonate (PC)
The housing is made from polycarbonate.
	1. First replacement option:
	another plastic sheet material that is suited for medical use, i.e. frequently wiped of with alcohol.

Bolts and Nuts
Stainless steel fasteners should be used.
	1. First replacement option:
	Other type of corrosion free steel coated fasteners


